<h3>Hi  {{ $corporate_name }},</h3>
<h4>Thank you for Registering, Below are the login details to Corporate portal</h4>
<p>Username : {{ $corporate_email  }}</p>
<p>Password : {{ $corporate_password }}</p>
<p>Link : https://datahatchworks.co.ke/login</p>