<h3>Hi  <?php echo e($corporate_name); ?>,</h3>
<h4>Thank you for Registering, Below are the login details to Corporate portal</h4>
<p>Username : <?php echo e($corporate_email); ?></p>
<p>Password : <?php echo e($corporate_password); ?></p>
<p>Link : https://datahatchworks.co.ke/login</p><?php /**PATH C:\laragon\www\loyalty-system\resources\views/corporate_login_mail.blade.php ENDPATH**/ ?>